package com.mercadolibre.fresco.repository;

import com.mercadolibre.fresco.model.PurchaseOrder;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PurchaseOrderRepository extends JpaRepository<PurchaseOrder, Long> {


}
