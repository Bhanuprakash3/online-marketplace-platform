package com.mercadolibre.fresco.service.crud;

import com.mercadolibre.fresco.model.Role;

public interface IRoleService extends ICRUD<Role> {
}
