package com.mercadolibre.fresco.service.crud;

import com.mercadolibre.fresco.model.User;

public interface IUserService extends ICRUD<User> {
}
